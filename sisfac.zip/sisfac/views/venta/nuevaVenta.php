<?php
require_once ROOT_PATH."views/layout/header.php";
 ?>

  <!-- Begin Page Content -->
  <div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Nuevo Registro de Venta</h1>  
    </div>

    <!-- Content Row -->
    <div class="row">
    <div class="card-body shadow">

    
    <form method="post" action="?c=venta&a=guardar">
        <div class="row mb-3">
            <label for="cliente" class="col-sm-2 col-form-label">Cliente</label>
            <div class="col-sm-4">
                <select class="form-control" name="cliente" required>
                    <option value="0">Seleccione Cliente</option> 
                    <?php
                    $ocli = new ModeloCliente();
                    $datocli = $ocli->listaClientes();
                    foreach($datocli as $filacli) {
                        echo "<option value='".$filacli["idcliente"]."'>".$filacli["nomcliente"]."</option>";
                    } 
                    ?>
                </select>
            </div>
        </div>
        <div class="row mb-3">
            <label for="documento" class="col-sm-2 col-form-label">Documento</label>
            <div class="col-sm-4">
            <select class="form-control" name="documento" required>
                <option value="0">Seleccione Tipo Documento</option> 
                <option value="F">Factura de Venta</option> 
                <option value="B">Boleta de Venta</option> 
            </select>
            </div>
          </div>
<!-- Detalle de venta -->
<div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Descripcion</th>
                        <th>Und</th>
                        <th>Cant</th>
                        <th>Precio</th>
                        <th>Costo</th>
                        <th>Importe</th>                       
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                       foreach ($datos as $row) {
                    ?>
                    <tr>
                        
                        <td>
                        <a href="index.php?c=venta&a=verDetalle&id=<?php echo $row['id']; ?>" class="btn btn-success btn-circle btn-sm">
                                        <i class="fas fa-check"></i>
                        </a>
                        <a href="index.php?c=venta&a=borrar&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-circle btn-sm">
                                        <i class="fas fa-trash"></i>
                                    </a>
                        </td>
                    </tr>
                    <?php } ?>

                </tbody>
            </table>
        </div>
    </div>

          <hr>
          <div class="row mb-3">          
          <div class="col-sm-6">
           
            <input class="btn btn-primary" type="submit" value="Guardar">
            <a class="btn btn-secondary" href="?c=venta&a=index">Cancelar</a>
            </div>
        </div>
        </form>
      </div>
    </div>

    

  </div>
  <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
<?php
require_once ROOT_PATH."views/layout/footer.php";
 ?>
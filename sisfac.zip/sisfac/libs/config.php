<?php
    define("DB_HOST", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "");
    define("DB_NAME", "sisfac");

    define("CONTROLADOR_PRINCIPAL", "Inicio");
	define("ACCION_PRINCIPAL", "index");

    define('ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/sisfac/');
    define('EMPRESA', 'La Clarita SA');
?>